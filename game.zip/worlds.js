var WorldsData = {
  version: 1,
  worlds: {
    default: {
      id: "default",
      name: "Forest Clearing",
      data: {
        settings: {
          communityGoal: 10000,
          bottleCO2Grams: 15
        },
        collections: {
          species: [
            { id: "oak", name: "Oak", unlockAt: 0, emoji: "🌳", leafColor: "#4caf50" },
            { id: "pine", name: "Pine", unlockAt: 5, emoji: "🌲", leafColor: "#2d6a4f" },
            { id: "cherry", name: "Cherry Blossom", unlockAt: 15, emoji: "🌸", leafColor: "#ffb6c1" },
            { id: "birch", name: "Birch", unlockAt: 30, emoji: "🪾", leafColor: "#a5d6a7" },
            { id: "willow", name: "Willow", unlockAt: 50, emoji: "🍃", leafColor: "#9ccc65" }
          ]
        }
      }
    }
  },
  connections: []
};
