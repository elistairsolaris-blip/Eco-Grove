// A planted tree. Grows through stages 0..5 as it receives growth points.
// Stage 0 = seed/sprout, 5 = mature.
class Tree extends GameObject {
  constructor(x, groundY, speciesId) {
    super(x - 50, groundY - 180, 100, 180);
    this.groundY = groundY;
    this.speciesId = speciesId;
    this.species = Species_byId(speciesId);
    this.growth = 0;        // 0..1 within current stage
    this.stage = 0;         // 0..5
    this.points = 0;        // total growth points received
    this.sway = Math.random() * Math.PI * 2;
    this.swaySpeed = 0.6 + Math.random() * 0.4;
    this.popPulse = 0;      // 0..1 pop animation on growth
    this.wateredPulse = 0;
  }

  addGrowth(points) {
    this.points += points;
    const prevStage = this.stage;
    // 1 bottle = ~0.25 stage progress; mature at 5 stages ~= 20 points.
    const target = Math.min(5, this.points * 0.25);
    this.stage = Math.floor(target);
    this.growth = target - this.stage;
    if (this.stage > prevStage) this.popPulse = 1;
  }

  water() {
    // Water adds a tiny boost but mostly a visual pulse.
    this.points += 0.4;
    const target = Math.min(5, this.points * 0.25);
    const prevStage = this.stage;
    this.stage = Math.floor(target);
    this.growth = target - this.stage;
    if (this.stage > prevStage) this.popPulse = 1;
    this.wateredPulse = 1;
  }

  isMature() { return this.stage >= 5; }

  update(dt) {
    this.sway += dt * this.swaySpeed;
    if (this.popPulse > 0) this.popPulse = Math.max(0, this.popPulse - dt * 1.6);
    if (this.wateredPulse > 0) this.wateredPulse = Math.max(0, this.wateredPulse - dt * 1.4);
  }

  // Returns current visual height based on stage + partial growth.
  visualHeight() {
    const stageHeights = [14, 36, 64, 100, 140, 180];
    const a = stageHeights[this.stage];
    const b = stageHeights[Math.min(5, this.stage + 1)];
    const base = a + (b - a) * this.growth;
    const pop = 1 + this.popPulse * 0.18;
    return base * pop;
  }

  draw(ctx) {
    const h = this.visualHeight();
    const w = h * 0.75;
    const baseX = this.x + this.width / 2;
    const baseY = this.groundY;
    const swayAngle = Math.sin(this.sway) * 0.03 * Math.min(1, this.stage / 3);

    // Shadow
    ctx.fillStyle = 'rgba(0,0,0,0.15)';
    ctx.beginPath();
    ctx.ellipse(baseX, baseY + 4, Math.max(14, w * 0.45), Math.max(4, w * 0.1), 0, 0, Math.PI * 2);
    ctx.fill();

    ctx.save();
    ctx.translate(baseX, baseY);
    ctx.rotate(swayAngle);

    if (this.stage === 0) {
      this._drawSprout(ctx, h);
    } else {
      this._drawTrunk(ctx, h, w);
      this._drawCanopy(ctx, h, w);
    }

    // Water droplet sparkle
    if (this.wateredPulse > 0) {
      ctx.fillStyle = `rgba(140,210,255,${0.6 * this.wateredPulse})`;
      for (let i = 0; i < 4; i++) {
        const a = (i / 4) * Math.PI * 2 + this.sway;
        const r = h * 0.5 + 6;
        ctx.beginPath();
        ctx.arc(Math.cos(a) * r * 0.6, -h * 0.55 + Math.sin(a) * r * 0.3, 3, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    ctx.restore();
  }

  _drawSprout(ctx, h) {
    // Little green sprout from the ground
    const t = Math.max(10, h);
    ctx.strokeStyle = '#4caf50';
    ctx.lineWidth = 3;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(0, -t);
    ctx.stroke();
    // leaves
    ctx.fillStyle = '#66bb6a';
    ctx.beginPath();
    ctx.ellipse(-5, -t + 2, 5, 3, -0.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(5, -t + 5, 5, 3, 0.5, 0, Math.PI * 2);
    ctx.fill();
  }

  _drawTrunk(ctx, h, w) {
    const sp = this.species;
    const trunkH = h * (sp.shape === 'cone' ? 0.25 : sp.shape === 'tall' ? 0.55 : 0.35);
    const trunkW = Math.max(4, w * 0.12);
    ctx.fillStyle = sp.bark;
    ctx.beginPath();
    ctx.moveTo(-trunkW / 2, 0);
    ctx.lineTo(trunkW / 2, 0);
    ctx.lineTo(trunkW / 2 * 0.6, -trunkH);
    ctx.lineTo(-trunkW / 2 * 0.6, -trunkH);
    ctx.closePath();
    ctx.fill();

    // Birch stripes
    if (sp.barkStripe) {
      ctx.fillStyle = sp.barkStripe;
      const stripes = Math.max(2, Math.floor(trunkH / 10));
      for (let i = 0; i < stripes; i++) {
        const y = -trunkH * (i + 0.5) / stripes;
        ctx.fillRect(-trunkW / 2, y, trunkW, 2);
      }
    }
  }

  _drawCanopy(ctx, h, w) {
    const sp = this.species;
    const trunkH = h * (sp.shape === 'cone' ? 0.25 : sp.shape === 'tall' ? 0.55 : 0.35);
    const canopyY = -trunkH;
    const canopyH = h - trunkH;
    const canopyW = w;

    if (sp.shape === 'cone') {
      // Pine — stacked triangles
      const layers = 3;
      for (let i = 0; i < layers; i++) {
        const ly = canopyY - (canopyH / layers) * i;
        const lw = canopyW * (1 - i * 0.18);
        const lh = canopyH / layers * 1.2;
        ctx.fillStyle = i % 2 === 0 ? sp.leafA : sp.leafB;
        ctx.beginPath();
        ctx.moveTo(-lw / 2, ly);
        ctx.lineTo(lw / 2, ly);
        ctx.lineTo(0, ly - lh);
        ctx.closePath();
        ctx.fill();
      }
    } else if (sp.shape === 'droop') {
      // Willow — round canopy + drooping strands
      ctx.fillStyle = sp.leafA;
      ctx.beginPath();
      ctx.ellipse(0, canopyY - canopyH * 0.4, canopyW * 0.55, canopyH * 0.55, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = sp.leafB;
      ctx.lineWidth = 2;
      ctx.lineCap = 'round';
      for (let i = 0; i < 7; i++) {
        const a = -Math.PI + (i / 6) * Math.PI;
        const sx = Math.cos(a) * canopyW * 0.5;
        const sy = canopyY - canopyH * 0.3 + Math.sin(a) * canopyH * 0.3;
        ctx.beginPath();
        ctx.moveTo(sx, sy);
        ctx.quadraticCurveTo(sx * 1.1, sy + canopyH * 0.2, sx * 0.9, sy + canopyH * 0.45);
        ctx.stroke();
      }
    } else if (sp.shape === 'tall') {
      // Birch — narrow oval
      ctx.fillStyle = sp.leafA;
      ctx.beginPath();
      ctx.ellipse(0, canopyY - canopyH * 0.45, canopyW * 0.4, canopyH * 0.5, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = sp.leafB;
      ctx.beginPath();
      ctx.ellipse(-canopyW * 0.1, canopyY - canopyH * 0.55, canopyW * 0.25, canopyH * 0.3, 0, 0, Math.PI * 2);
      ctx.fill();
    } else {
      // Round (oak, cherry)
      ctx.fillStyle = sp.leafB;
      ctx.beginPath();
      ctx.arc(-canopyW * 0.2, canopyY - canopyH * 0.3, canopyW * 0.35, 0, Math.PI * 2);
      ctx.arc(canopyW * 0.2, canopyY - canopyH * 0.3, canopyW * 0.35, 0, Math.PI * 2);
      ctx.arc(0, canopyY - canopyH * 0.55, canopyW * 0.38, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = sp.leafA;
      ctx.beginPath();
      ctx.arc(-canopyW * 0.1, canopyY - canopyH * 0.4, canopyW * 0.28, 0, Math.PI * 2);
      ctx.arc(canopyW * 0.15, canopyY - canopyH * 0.5, canopyW * 0.26, 0, Math.PI * 2);
      ctx.fill();
      // Cherry blossoms highlight
      if (sp.accent) {
        ctx.fillStyle = sp.accent;
        for (let i = 0; i < 6; i++) {
          const a = (i / 6) * Math.PI * 2;
          const r = canopyW * 0.3;
          ctx.beginPath();
          ctx.arc(Math.cos(a) * r, canopyY - canopyH * 0.4 + Math.sin(a) * r * 0.7, 3, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    }
  }
}
