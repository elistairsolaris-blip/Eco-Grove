// Scenery sprites — stamped by Game.js as decor behind the trees.

Assets.sprite('cloud', 200, 90, (ctx, w, h) => {
  ctx.fillStyle = 'rgba(255,255,255,0.92)';
  ctx.beginPath();
  ctx.arc(w * 0.25, h * 0.6, h * 0.35, 0, Math.PI * 2);
  ctx.arc(w * 0.45, h * 0.45, h * 0.45, 0, Math.PI * 2);
  ctx.arc(w * 0.65, h * 0.5, h * 0.4, 0, Math.PI * 2);
  ctx.arc(w * 0.82, h * 0.62, h * 0.32, 0, Math.PI * 2);
  ctx.fill();
});

Assets.sprite('sun', 160, 160, (ctx, w, h) => {
  const cx = w / 2, cy = h / 2;
  // halo
  const grd = ctx.createRadialGradient(cx, cy, w * 0.2, cx, cy, w * 0.5);
  grd.addColorStop(0, 'rgba(255,236,150,0.75)');
  grd.addColorStop(1, 'rgba(255,236,150,0)');
  ctx.fillStyle = grd;
  ctx.beginPath(); ctx.arc(cx, cy, w * 0.49, 0, Math.PI * 2); ctx.fill();
  // rays
  ctx.strokeStyle = '#ffd766';
  ctx.lineWidth = w * 0.025;
  ctx.lineCap = 'round';
  for (let i = 0; i < 10; i++) {
    const a = (i / 10) * Math.PI * 2;
    const r1 = w * 0.28, r2 = w * 0.38;
    ctx.beginPath();
    ctx.moveTo(cx + Math.cos(a) * r1, cy + Math.sin(a) * r1);
    ctx.lineTo(cx + Math.cos(a) * r2, cy + Math.sin(a) * r2);
    ctx.stroke();
  }
  // body
  ctx.fillStyle = '#ffd766';
  ctx.beginPath(); ctx.arc(cx, cy, w * 0.22, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = '#ffe9a3';
  ctx.beginPath(); ctx.arc(cx - w * 0.04, cy - w * 0.04, w * 0.17, 0, Math.PI * 2); ctx.fill();
});

Assets.sprite('bush', 90, 60, (ctx, w, h) => {
  ctx.fillStyle = '#5fae55';
  ctx.beginPath();
  ctx.arc(w * 0.25, h * 0.65, h * 0.4, 0, Math.PI * 2);
  ctx.arc(w * 0.5, h * 0.5, h * 0.48, 0, Math.PI * 2);
  ctx.arc(w * 0.75, h * 0.65, h * 0.4, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = 'rgba(255,255,255,0.15)';
  ctx.beginPath();
  ctx.arc(w * 0.45, h * 0.35, h * 0.18, 0, Math.PI * 2);
  ctx.fill();
});

Assets.sprite('flower', 36, 36, (ctx, w, h) => {
  const cx = w / 2, cy = h / 2;
  ctx.fillStyle = '#ff8ab3';
  for (let i = 0; i < 5; i++) {
    const a = (i / 5) * Math.PI * 2;
    ctx.beginPath();
    ctx.arc(cx + Math.cos(a) * w * 0.22, cy + Math.sin(a) * h * 0.22, w * 0.17, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.fillStyle = '#ffd766';
  ctx.beginPath(); ctx.arc(cx, cy, w * 0.14, 0, Math.PI * 2); ctx.fill();
});

Assets.sprite('rock', 70, 40, (ctx, w, h) => {
  ctx.fillStyle = '#9aa1a8';
  ctx.beginPath();
  ctx.moveTo(w * 0.1, h * 0.9);
  ctx.quadraticCurveTo(w * 0.0, h * 0.4, w * 0.35, h * 0.2);
  ctx.quadraticCurveTo(w * 0.75, h * 0.1, w * 0.95, h * 0.5);
  ctx.quadraticCurveTo(w * 1.0, h * 0.9, w * 0.9, h * 0.95);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = 'rgba(255,255,255,0.25)';
  ctx.beginPath();
  ctx.ellipse(w * 0.4, h * 0.35, w * 0.2, h * 0.08, -0.3, 0, Math.PI * 2);
  ctx.fill();
});

Assets.sprite('bin', 70, 90, (ctx, w, h) => {
  // Recycling bin
  ctx.fillStyle = '#2e7d32';
  ctx.beginPath();
  ctx.moveTo(w * 0.15, h * 0.25);
  ctx.lineTo(w * 0.85, h * 0.25);
  ctx.lineTo(w * 0.78, h * 0.95);
  ctx.lineTo(w * 0.22, h * 0.95);
  ctx.closePath();
  ctx.fill();
  // lid
  ctx.fillStyle = '#1b5e20';
  ctx.fillRect(w * 0.1, h * 0.18, w * 0.8, h * 0.1);
  // recycle symbol
  ctx.strokeStyle = '#bffb76';
  ctx.lineWidth = w * 0.06;
  ctx.lineCap = 'round';
  ctx.beginPath();
  const cx = w / 2, cy = h * 0.6, r = w * 0.22;
  for (let i = 0; i < 3; i++) {
    const a0 = (i / 3) * Math.PI * 2 - Math.PI / 2;
    const a1 = a0 + Math.PI * 0.5;
    ctx.moveTo(cx + Math.cos(a0) * r, cy + Math.sin(a0) * r);
    ctx.arc(cx, cy, r, a0, a1);
  }
  ctx.stroke();
});
