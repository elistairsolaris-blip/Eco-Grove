// Badge definitions and evaluation helpers.
const BadgeCatalog = [
  { id: 'first_bottle', name: 'First Deposit', icon: '🥇', desc: 'Recycle your first bottle',
    check: (p) => p.bottles >= 1 },
  { id: 'ten_bottles',  name: 'Getting Started', icon: '♻️', desc: 'Recycle 10 bottles',
    check: (p) => p.bottles >= 10 },
  { id: 'first_tree',   name: 'First Tree', icon: '🌳', desc: 'Grow a tree to maturity',
    check: (p) => p.treesMatured >= 1 },
  { id: 'forest_five',  name: 'Mini Forest', icon: '🌲', desc: 'Grow 5 mature trees',
    check: (p) => p.treesMatured >= 5 },
  { id: 'all_species',  name: 'Species Collector', icon: '🏆', desc: 'Unlock all 5 species',
    check: (p) => p.bottles >= 50 },
  { id: 'community',    name: 'Community Hero', icon: '🌍', desc: 'Contribute 25 bottles',
    check: (p) => p.bottles >= 25 }
];

function Badges_newlyEarned(player) {
  const earned = player.badges || [];
  const out = [];
  for (const b of BadgeCatalog) {
    if (!earned.includes(b.id) && b.check(player)) out.push(b);
  }
  return out;
}

function Badges_byId(id) { return BadgeCatalog.find(b => b.id === id); }
