// Species catalog — colors, names, and shape type for painting trees.
const SpeciesCatalog = [
  {
    id: 'oak',
    name: 'Oak',
    unlockAt: 0,
    shape: 'round',
    bark: '#8b5a2b',
    leafA: '#4caf50',
    leafB: '#2e7d32',
    accent: null,
    emoji: '🌳',
    co2: 15,
    hint: 'Starter species'
  },
  {
    id: 'pine',
    name: 'Pine',
    unlockAt: 5,
    shape: 'cone',
    bark: '#6d4423',
    leafA: '#2d6a4f',
    leafB: '#1b4332',
    accent: null,
    emoji: '🌲',
    co2: 22,
    hint: 'Recycle 5 bottles'
  },
  {
    id: 'cherry',
    name: 'Cherry Blossom',
    unlockAt: 15,
    shape: 'round',
    bark: '#7a4e3a',
    leafA: '#ffb6c1',
    leafB: '#ff8ab3',
    accent: '#fff0f5',
    emoji: '🌸',
    co2: 18,
    hint: 'Recycle 15 bottles'
  },
  {
    id: 'birch',
    name: 'Birch',
    unlockAt: 30,
    shape: 'tall',
    bark: '#eceff1',
    barkStripe: '#2d3a2e',
    leafA: '#a5d6a7',
    leafB: '#66bb6a',
    accent: null,
    emoji: '🪾',
    co2: 14,
    hint: 'Recycle 30 bottles'
  },
  {
    id: 'willow',
    name: 'Willow',
    unlockAt: 50,
    shape: 'droop',
    bark: '#6b4a2a',
    leafA: '#9ccc65',
    leafB: '#689f38',
    accent: null,
    emoji: '🍃',
    co2: 25,
    hint: 'Recycle 50 bottles'
  }
];

function Species_byId(id) {
  return SpeciesCatalog.find(s => s.id === id) || SpeciesCatalog[0];
}

function Species_unlockedCount(bottles) {
  return SpeciesCatalog.filter(s => bottles >= s.unlockAt).length;
}

function Species_nextLock(bottles) {
  return SpeciesCatalog.find(s => bottles < s.unlockAt) || null;
}
