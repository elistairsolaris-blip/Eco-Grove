// Floating leaf / sparkle particle.
class Particle extends GameObject {
  constructor(x, y, opts = {}) {
    super(x - 6, y - 6, 12, 12);
    this.vx = opts.vx != null ? opts.vx : (Math.random() - 0.5) * 60;
    this.vy = opts.vy != null ? opts.vy : -40 - Math.random() * 60;
    this.life = opts.life || 2.2;
    this.age = 0;
    this.spin = (Math.random() - 0.5) * 4;
    this.rot = Math.random() * Math.PI * 2;
    this.kind = opts.kind || 'leaf'; // 'leaf' | 'sparkle' | 'water'
    this.color = opts.color || '#8bc34a';
    this.size = opts.size || 8;
    this.gravity = opts.gravity != null ? opts.gravity : (this.kind === 'water' ? 220 : 20);
    this.sway = Math.random() * Math.PI * 2;
  }

  update(dt) {
    this.age += dt;
    if (this.age >= this.life) { this.dead = true; return; }
    this.sway += dt * 3;
    const swayX = this.kind === 'leaf' ? Math.sin(this.sway) * 25 : 0;
    this.x += (this.vx + swayX) * dt;
    this.y += this.vy * dt;
    this.vy += this.gravity * dt;
    this.vx *= 0.995;
    this.rot += this.spin * dt;
  }

  draw(ctx) {
    const t = 1 - this.age / this.life;
    const alpha = Math.min(1, t * 1.6);
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.translate(this.x + 6, this.y + 6);
    ctx.rotate(this.rot);
    if (this.kind === 'sparkle') {
      ctx.fillStyle = this.color;
      const s = this.size;
      ctx.beginPath();
      for (let i = 0; i < 4; i++) {
        const a = (i / 4) * Math.PI * 2;
        ctx.lineTo(Math.cos(a) * s, Math.sin(a) * s);
        const a2 = a + Math.PI / 4;
        ctx.lineTo(Math.cos(a2) * s * 0.4, Math.sin(a2) * s * 0.4);
      }
      ctx.closePath();
      ctx.fill();
    } else if (this.kind === 'water') {
      ctx.fillStyle = this.color;
      ctx.beginPath();
      ctx.ellipse(0, 0, this.size * 0.5, this.size, 0, 0, Math.PI * 2);
      ctx.fill();
    } else {
      // leaf
      ctx.fillStyle = this.color;
      ctx.beginPath();
      ctx.ellipse(0, 0, this.size, this.size * 0.55, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = 'rgba(0,0,0,0.2)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(-this.size, 0);
      ctx.lineTo(this.size, 0);
      ctx.stroke();
    }
    ctx.restore();
  }
}
