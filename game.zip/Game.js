class Game {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.entities = [];
    this.trees = [];
    this.particles = [];
    this.decor = [];
    this.state = 'idle';
    this.lastTime = 0;
    this.time = 0;

    // Design resolution (portrait 720x1280)
    this.W = 720;
    this.H = 1280;
    this.groundY = this.H - 180;

    // Simulated community totals — settings sourced from the world document
    this.communityBottles = 2140 + Math.floor(Math.random() * 400);
    this._loadWorldSettings();
    if (window.Worlds && Worlds.onChange) {
      Worlds.onChange(() => { this._loadWorldSettings(); this._applySpeciesFromWorld(); this._updateHUD(); this._renderMenu(); });
    }
    this.feedCooldown = 2.5;
    this.feedTimer = 1.5;

    this.activeTreeIndex = 0;
    this.player = {
      bottles: 0,
      co2: 0,
      badges: [],
      treesMatured: 0,
      forest: []  // persisted species ids at planted positions
    };

    this._initSaveData();
    this._setupCanvas();
    this._buildScene();
    this._bindUI();
    this._pushFeed('🌍 Welcome! Tap SCAN to recycle your first bottle.', true);
    this._renderMenu();
    this._updateHUD();
    this.start();
  }

  _loadWorldSettings() {
    const w = window.Worlds ? Worlds.get(Worlds.list()[0]) : null;
    const s = (w && w.data && w.data.settings) || {};
    this.communityGoal = s.communityGoal != null ? s.communityGoal : 10000;
    this.bottleCO2Grams = s.bottleCO2Grams != null ? s.bottleCO2Grams : 15;
    this._applySpeciesFromWorld();
  }

  _applySpeciesFromWorld() {
    const w = window.Worlds ? Worlds.get(Worlds.list()[0]) : null;
    const rows = (w && w.data && w.data.collections && w.data.collections.species) || null;
    if (!rows || !rows.length) return;
    // Patch SpeciesCatalog entries in-place with world data (name, unlockAt, emoji, leaf color)
    for (const row of rows) {
      const sp = SpeciesCatalog.find(x => x.id === row.id);
      if (!sp) continue;
      if (row.name) sp.name = row.name;
      if (typeof row.unlockAt === 'number') sp.unlockAt = row.unlockAt;
      if (row.emoji) sp.emoji = row.emoji;
      if (row.leafColor) sp.leafA = row.leafColor;
      sp.hint = row.unlockAt > 0 ? `Recycle ${row.unlockAt} bottles` : 'Starter species';
    }
  }

  async _initSaveData() {
    if (!window.SaveData) return;
    const data = await SaveData.init({
      bottles: 0,
      co2: 0,
      badges: [],
      treesMatured: 0,
      forest: [],
      activeTreeIndex: 0,
      leaderboard: [
        { field: 'bottles', label: 'Bottles recycled' },
        { field: 'treesMatured', label: 'Trees grown' }
      ]
    });
    this.save = data;
    // Hydrate state
    this.player.bottles = data.bottles || 0;
    this.player.co2 = data.co2 || 0;
    this.player.badges = Array.isArray(data.badges) ? data.badges.slice() : [];
    this.player.treesMatured = data.treesMatured || 0;
    this.player.forest = Array.isArray(data.forest) ? data.forest.slice() : [];
    this.activeTreeIndex = data.activeTreeIndex || 0;
    this._rebuildTreesFromSave();
    this._updateHUD();
    this._renderMenu();
  }

  _persist() {
    if (!this.save) return;
    this.save.bottles = this.player.bottles;
    this.save.co2 = this.player.co2;
    this.save.badges = this.player.badges.slice();
    this.save.treesMatured = this.player.treesMatured;
    this.save.forest = this.player.forest.slice();
    this.save.activeTreeIndex = this.activeTreeIndex;
  }

  _setupCanvas() {
    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const rect = this.canvas.getBoundingClientRect();
      this.canvas.width = Math.max(1, Math.floor(rect.width * dpr));
      this.canvas.height = Math.max(1, Math.floor(rect.height * dpr));
      // Compute uniform scale to fit design space into canvas
      const sx = this.canvas.width / this.W;
      const sy = this.canvas.height / this.H;
      this.scale = Math.min(sx, sy);
      this.offsetX = (this.canvas.width - this.W * this.scale) / 2;
      this.offsetY = (this.canvas.height - this.H * this.scale) / 2;
    };
    resize();
    window.addEventListener('resize', resize);
  }

  _buildScene() {
    // Decor placements (sprite stamps, selectable in editor if present)
    this.decor = [
      { sprite: 'sun', x: 480, y: 90, w: 180, h: 180 },
      { sprite: 'cloud', x: 30, y: 120, w: 200, h: 90, drift: 8 },
      { sprite: 'cloud', x: 260, y: 220, w: 160, h: 70, drift: 12 },
      { sprite: 'cloud', x: 520, y: 300, w: 180, h: 80, drift: 6 },
      { sprite: 'bush', x: 20, y: this.groundY - 20, w: 110, h: 70 },
      { sprite: 'bush', x: 560, y: this.groundY - 25, w: 130, h: 80 },
      { sprite: 'rock', x: 180, y: this.groundY + 20, w: 70, h: 40 },
      { sprite: 'rock', x: 440, y: this.groundY + 30, w: 60, h: 36 },
      { sprite: 'flower', x: 70, y: this.groundY + 40, w: 32, h: 32 },
      { sprite: 'flower', x: 300, y: this.groundY + 60, w: 28, h: 28 },
      { sprite: 'flower', x: 400, y: this.groundY + 35, w: 32, h: 32 },
      { sprite: 'flower', x: 620, y: this.groundY + 55, w: 30, h: 30 },
      { sprite: 'bin', x: this.W - 110, y: this.groundY - 90, w: 80, h: 100 }
    ];

    // Start with one seedling (Oak) if no saved forest
    if (this.trees.length === 0) {
      const t = new Tree(this.W / 2, this.groundY, 'oak');
      this.trees.push(t);
      this.entities.push(t);
    }
  }

  _rebuildTreesFromSave() {
    // Remove existing trees
    for (const t of this.trees) t.dead = true;
    this.entities = this.entities.filter(e => !(e instanceof Tree));
    this.trees = [];

    const positions = this._treeSlots(this.player.forest.length || 1);
    const n = Math.max(1, this.player.forest.length);
    for (let i = 0; i < n; i++) {
      const species = this.player.forest[i] || 'oak';
      const t = new Tree(positions[i], this.groundY, species);
      // Mature saved past trees (except the active one), active resumes growing
      if (i !== this.activeTreeIndex) {
        t.points = 20; t.stage = 5; t.growth = 0;
      }
      this.trees.push(t);
      this.entities.push(t);
    }
    // If forest array is empty, activeTreeIndex is 0 and we have 1 tree
    if (this.player.forest.length === 0) this.activeTreeIndex = 0;
  }

  _treeSlots(count) {
    const slots = [];
    const maxPerRow = 5;
    const rows = Math.max(1, Math.ceil(count / maxPerRow));
    const rowGap = 60;
    for (let r = 0; r < rows; r++) {
      const inRow = Math.min(maxPerRow, count - r * maxPerRow);
      const spacing = (this.W - 160) / Math.max(1, inRow);
      for (let i = 0; i < inRow; i++) {
        const x = 80 + spacing * (i + 0.5);
        const y = this.groundY - r * rowGap;
        slots.push(x);
        // we only use x; y is implied by groundY
      }
    }
    return slots;
  }

  _bindUI() {
    const $ = (id) => document.getElementById(id);
    this.ui = {
      bottlesStat: $('bottlesStat'),
      co2Stat: $('co2Stat'),
      communityCount: $('communityCount'),
      communityFill: $('communityFill'),
      activityFeed: $('activityFeed'),
      scanBtn: $('scanBtn'),
      waterBtn: $('waterBtn'),
      forestBtn: $('forestBtn'),
      menuBtn: $('menuBtn'),
      scanOverlay: $('scanOverlay'),
      scanStatus: $('scanStatus'),
      scanCancel: $('scanCancel'),
      rewardOverlay: $('rewardOverlay'),
      rewardTitle: $('rewardTitle'),
      rewardText: $('rewardText'),
      rewardSpecies: $('rewardSpecies'),
      rewardOk: $('rewardOk'),
      menuOverlay: $('menuOverlay'),
      menuClose: $('menuClose'),
      mBottles: $('mBottles'),
      mCO2: $('mCO2'),
      mTrees: $('mTrees'),
      mSpecies: $('mSpecies'),
      speciesList: $('speciesList'),
      badgeList: $('badgeList'),
      badgeToast: $('badgeToast'),
      toastName: $('toastName')
    };

    this.ui.scanBtn.addEventListener('click', () => this._openScan());
    this.ui.scanCancel.addEventListener('click', () => this._closeScan());
    this.ui.waterBtn.addEventListener('click', () => this._water());
    this.ui.forestBtn.addEventListener('click', () => this._cycleActiveTree());
    this.ui.menuBtn.addEventListener('click', () => this._openMenu());
    this.ui.menuClose.addEventListener('click', () => this._closeMenu());
    this.ui.rewardOk.addEventListener('click', () => this._closeReward());

    // Tap on canvas = tap active tree for a little love
    this.canvas.addEventListener('click', (e) => {
      if (this.state !== 'idle') return;
      // sparkle particles on the active tree
      const t = this.trees[this.activeTreeIndex];
      if (!t) return;
      const cx = t.x + t.width / 2;
      const cy = this.groundY - t.visualHeight() * 0.6;
      for (let i = 0; i < 5; i++) {
        this._spawnParticle(cx, cy, { kind: 'sparkle', color: '#fff2a8', size: 4, life: 1 });
      }
    });
  }

  // ---------- Scan flow ----------
  _openScan() {
    if (this.state !== 'idle') return;
    this.state = 'scanning';
    this.ui.scanOverlay.classList.remove('hidden');
    this.ui.scanStatus.textContent = 'Hold steady… scanning bottle QR';
    // Simulate 1.4s scan
    this._scanTimer = setTimeout(() => {
      this.ui.scanStatus.textContent = '✅ Bottle verified!';
      this._scanTimer = setTimeout(() => {
        this._closeScan();
        this._depositBottle();
      }, 500);
    }, 1400);
  }

  _closeScan() {
    if (this._scanTimer) { clearTimeout(this._scanTimer); this._scanTimer = null; }
    this.ui.scanOverlay.classList.add('hidden');
    if (this.state === 'scanning') this.state = 'idle';
  }

  _depositBottle() {
    this.player.bottles += 1;
    this.player.co2 += this.bottleCO2Grams || 15;
    this.communityBottles += 1 + Math.floor(Math.random() * 3);

    // Grow active tree
    const tree = this.trees[this.activeTreeIndex];
    let unlockedSpecies = null;
    if (tree) {
      const prevMature = tree.isMature();
      tree.addGrowth(1);
      // Particle burst at tree
      const cx = tree.x + tree.width / 2;
      const cy = this.groundY - tree.visualHeight() * 0.7;
      for (let i = 0; i < 10; i++) {
        this._spawnParticle(cx, cy, {
          kind: 'leaf',
          color: tree.species.leafA,
          size: 6 + Math.random() * 4,
          vx: (Math.random() - 0.5) * 120,
          vy: -80 - Math.random() * 80,
          life: 2 + Math.random()
        });
      }
      // If it just matured, award, auto-plant next tree, and maybe unlock species
      if (!prevMature && tree.isMature()) {
        this.player.treesMatured += 1;
        this.player.forest[this.activeTreeIndex] = tree.speciesId;
        unlockedSpecies = this._tryUnlockNewSpecies();
        this._plantNextTree(unlockedSpecies);
      }
    }

    this._pushFeed(`♻️ You recycled a bottle! +1 growth`);
    this._updateHUD();
    this._showReward(unlockedSpecies);
    this._checkBadges();
    this._persist();
  }

  _tryUnlockNewSpecies() {
    // Returns a new species id if the player just crossed an unlock threshold
    for (const sp of SpeciesCatalog) {
      if (sp.unlockAt > 0 && this.player.bottles === sp.unlockAt) {
        return sp.id;
      }
    }
    // Also, if we haven't planted that species yet and threshold is met
    for (const sp of SpeciesCatalog) {
      if (this.player.bottles >= sp.unlockAt && !this.player.forest.includes(sp.id)) {
        return sp.id;
      }
    }
    return null;
  }

  _plantNextTree(preferredSpeciesId) {
    // Pick species: preferred if provided, else cycle through unlocked
    let species = preferredSpeciesId;
    if (!species) {
      const unlocked = SpeciesCatalog.filter(s => this.player.bottles >= s.unlockAt);
      species = unlocked[this.player.forest.length % unlocked.length].id;
    }
    const newIndex = this.player.forest.length;
    this.player.forest.push(species); // mature tree slot filled above; now add seedling
    // Rebuild positions with the extra tree slot
    const positions = this._treeSlots(this.player.forest.length + 1);
    // Move existing trees to new positions
    for (let i = 0; i < this.trees.length; i++) {
      this.trees[i].x = positions[i] - this.trees[i].width / 2;
    }
    const t = new Tree(positions[newIndex + 0] || this.W / 2, this.groundY, species);
    // Insert at the end
    this.trees.push(t);
    this.entities.push(t);
    this.activeTreeIndex = this.trees.length - 1;
    this._pushFeed(`🌱 New ${Species_byId(species).name} seedling planted!`);
  }

  _showReward(newSpeciesId) {
    this.ui.rewardOverlay.classList.remove('hidden');
    if (newSpeciesId) {
      const sp = Species_byId(newSpeciesId);
      this.ui.rewardTitle.textContent = 'New Species Unlocked!';
      this.ui.rewardText.textContent = `+1 bottle • +${this.bottleCO2Grams || 15}g CO₂ saved`;
      this.ui.rewardSpecies.textContent = `${sp.emoji} ${sp.name}`;
      this.ui.rewardSpecies.classList.remove('hidden');
    } else {
      this.ui.rewardTitle.textContent = 'Bottle Deposited!';
      this.ui.rewardText.textContent = `+1 bottle • +${this.bottleCO2Grams || 15}g CO₂ saved`;
      this.ui.rewardSpecies.classList.add('hidden');
    }
    this.state = 'reward';
  }

  _closeReward() {
    this.ui.rewardOverlay.classList.add('hidden');
    if (this.state === 'reward') this.state = 'idle';
  }

  // ---------- Water ----------
  _water() {
    if (this.state !== 'idle') return;
    const tree = this.trees[this.activeTreeIndex];
    if (!tree) return;
    tree.water();
    const cx = tree.x + tree.width / 2;
    const cy = this.groundY - tree.visualHeight();
    for (let i = 0; i < 8; i++) {
      this._spawnParticle(cx + (Math.random() - 0.5) * 40, cy - 20, {
        kind: 'water',
        color: '#8ec5ff',
        size: 4 + Math.random() * 3,
        vx: (Math.random() - 0.5) * 30,
        vy: 60 + Math.random() * 40,
        life: 1,
        gravity: 240
      });
    }
    this._pushFeed('💧 You watered your tree');
  }

  // ---------- Forest / active tree cycling ----------
  _cycleActiveTree() {
    if (this.trees.length === 0) return;
    // Prefer the next non-mature tree if any
    const start = (this.activeTreeIndex + 1) % this.trees.length;
    this.activeTreeIndex = start;
    const tree = this.trees[this.activeTreeIndex];
    this._pushFeed(`🌳 Now tending: ${tree.species.name}`);
    // Spark on the newly active tree
    const cx = tree.x + tree.width / 2;
    const cy = this.groundY - Math.max(30, tree.visualHeight()) * 0.8;
    for (let i = 0; i < 6; i++) {
      this._spawnParticle(cx, cy, { kind: 'sparkle', color: '#fff2a8', size: 5, life: 1 });
    }
  }

  // ---------- Menu / stats ----------
  _openMenu() {
    this._renderMenu();
    this.ui.menuOverlay.classList.remove('hidden');
    this.state = 'menu';
  }
  _closeMenu() {
    this.ui.menuOverlay.classList.add('hidden');
    if (this.state === 'menu') this.state = 'idle';
  }

  _renderMenu() {
    if (!this.ui) return;
    this.ui.mBottles.textContent = this.player.bottles;
    this.ui.mCO2.textContent = this._fmtCO2(this.player.co2);
    this.ui.mTrees.textContent = this.player.treesMatured;
    const unlocked = Species_unlockedCount(this.player.bottles);
    this.ui.mSpecies.textContent = `${unlocked} / ${SpeciesCatalog.length}`;

    this.ui.speciesList.innerHTML = '';
    for (const sp of SpeciesCatalog) {
      const locked = this.player.bottles < sp.unlockAt;
      const el = document.createElement('div');
      el.className = 'species-cell' + (locked ? ' locked' : '');
      el.innerHTML = `<span class="sp-swatch" style="background:${sp.leafA}">${sp.emoji}</span>` +
        `<div class="sp-info"><span class="sp-name">${sp.name}</span>` +
        `<span class="sp-unlock">${locked ? sp.hint : 'Unlocked'}</span></div>`;
      this.ui.speciesList.appendChild(el);
    }

    this.ui.badgeList.innerHTML = '';
    for (const b of BadgeCatalog) {
      const earned = this.player.badges.includes(b.id);
      const el = document.createElement('div');
      el.className = 'badge-cell' + (earned ? '' : ' locked');
      el.innerHTML = `<span class="bd-icon">${b.icon}</span>` +
        `<div class="bd-info"><span class="bd-name">${b.name}</span>` +
        `<span class="bd-desc">${b.desc}</span></div>`;
      this.ui.badgeList.appendChild(el);
    }
  }

  // ---------- HUD ----------
  _updateHUD() {
    if (!this.ui) return;
    this.ui.bottlesStat.textContent = this.player.bottles;
    this.ui.co2Stat.textContent = this._fmtCO2(this.player.co2);
    this.ui.communityCount.textContent = `${this.communityBottles.toLocaleString()} / ${this.communityGoal.toLocaleString()}`;
    const pct = Math.min(100, (this.communityBottles / this.communityGoal) * 100);
    this.ui.communityFill.style.width = pct.toFixed(1) + '%';
  }

  _fmtCO2(grams) {
    if (grams >= 1000) return (grams / 1000).toFixed(1) + 'kg';
    return grams + 'g';
  }

  // ---------- Badges ----------
  _checkBadges() {
    const earned = Badges_newlyEarned(this.player);
    if (earned.length === 0) return;
    for (const b of earned) {
      this.player.badges.push(b.id);
      this._queueBadgeToast(b);
    }
  }

  _queueBadgeToast(badge) {
    this.ui.toastName.textContent = badge.name;
    this.ui.badgeToast.classList.remove('hidden');
    clearTimeout(this._toastTimer);
    this._toastTimer = setTimeout(() => {
      this.ui.badgeToast.classList.add('hidden');
    }, 2200);
  }

  // ---------- Activity feed ----------
  _pushFeed(text, keep) {
    if (!this.ui || !this.ui.activityFeed) return;
    const el = document.createElement('div');
    el.className = 'feed-item';
    el.textContent = text;
    this.ui.activityFeed.appendChild(el);
    // Keep only last 4
    while (this.ui.activityFeed.children.length > 4) {
      this.ui.activityFeed.removeChild(this.ui.activityFeed.firstChild);
    }
    if (!keep) {
      setTimeout(() => {
        el.style.transition = 'opacity 0.6s, transform 0.6s';
        el.style.opacity = '0';
        el.style.transform = 'translateX(-1rem)';
        setTimeout(() => el.remove(), 650);
      }, 4500);
    }
  }

  _simulateCommunityActivity(dt) {
    this.feedTimer -= dt;
    if (this.feedTimer <= 0) {
      this.feedTimer = 5 + Math.random() * 6;
      const names = ['Mia', 'Leo', 'Aria', 'Kai', 'Zoe', 'Finn', 'Noor', 'Rafi', 'Luna', 'Theo'];
      const name = names[Math.floor(Math.random() * names.length)];
      const actions = [
        `${name} just recycled a bottle!`,
        `${name} grew a new ${SpeciesCatalog[Math.floor(Math.random() * SpeciesCatalog.length)].name}!`,
        `${name} unlocked a badge 🏅`,
        `${name} planted a seedling 🌱`
      ];
      this.communityBottles += 1 + Math.floor(Math.random() * 4);
      this._pushFeed(actions[Math.floor(Math.random() * actions.length)]);
      this._updateHUD();
    }
  }

  // ---------- Particles ----------
  _spawnParticle(x, y, opts) {
    const p = new Particle(x, y, opts);
    this.particles.push(p);
    this.entities.push(p);
  }

  // ---------- Loop ----------
  start() {
    const frame = (t) => {
      const dt = Math.min((t - this.lastTime) / 1000 || 0, 0.05);
      this.lastTime = t;
      this.update(dt);
      this.draw();
      requestAnimationFrame(frame);
    };
    requestAnimationFrame(frame);
  }

  update(dt) {
    this.time += dt;
    // Entities update even in overlay states so trees sway and leaves fall.
    for (const e of this.entities) e.update(dt);
    // Cleanup dead entities
    this.entities = this.entities.filter(e => !e.dead);
    this.particles = this.particles.filter(p => !p.dead);
    // Occasional ambient leaves from mature trees
    for (const t of this.trees) {
      if (t.isMature() && Math.random() < 0.004) {
        const cx = t.x + t.width / 2 + (Math.random() - 0.5) * 60;
        const cy = this.groundY - t.visualHeight() * (0.5 + Math.random() * 0.3);
        this._spawnParticle(cx, cy, {
          kind: 'leaf',
          color: t.species.leafA,
          size: 5 + Math.random() * 3,
          vx: (Math.random() - 0.5) * 20,
          vy: 20 + Math.random() * 20,
          life: 3,
          gravity: 10
        });
      }
    }
    this._simulateCommunityActivity(dt);
  }

  draw() {
    const ctx = this.ctx;
    // Clear full canvas
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.fillStyle = '#000';
    ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

    // Apply letterbox transform to design space
    ctx.setTransform(this.scale, 0, 0, this.scale, this.offsetX, this.offsetY);

    // Sky gradient
    const sky = ctx.createLinearGradient(0, 0, 0, this.H);
    sky.addColorStop(0, '#a8e6ff');
    sky.addColorStop(0.55, '#ffe9b3');
    sky.addColorStop(1, '#ffd166');
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, this.W, this.H);

    // Distant hills
    ctx.fillStyle = '#9bd48a';
    ctx.beginPath();
    ctx.moveTo(0, this.groundY - 20);
    ctx.quadraticCurveTo(this.W * 0.25, this.groundY - 80, this.W * 0.5, this.groundY - 30);
    ctx.quadraticCurveTo(this.W * 0.75, this.groundY - 90, this.W, this.groundY - 30);
    ctx.lineTo(this.W, this.groundY);
    ctx.lineTo(0, this.groundY);
    ctx.closePath();
    ctx.fill();

    // Ground
    ctx.fillStyle = '#7bc96f';
    ctx.fillRect(0, this.groundY, this.W, this.H - this.groundY);
    // Ground highlight
    ctx.fillStyle = 'rgba(255,255,255,0.15)';
    ctx.fillRect(0, this.groundY, this.W, 6);

    // Decor behind trees (sun & clouds)
    for (const d of this.decor) {
      if (d.sprite !== 'sun' && d.sprite !== 'cloud') continue;
      let dx = d.x;
      if (d.drift) dx = d.x + Math.sin(this.time * 0.2 + d.y) * d.drift;
      const img = lib.sprite(d.sprite);
      if (img) ctx.drawImage(img, dx, d.y, d.w, d.h);
    }

    // Decor at/behind ground level (bushes, rocks, bin)
    for (const d of this.decor) {
      if (d.sprite === 'sun' || d.sprite === 'cloud' || d.sprite === 'flower') continue;
      const img = lib.sprite(d.sprite);
      if (img) ctx.drawImage(img, d.x, d.y, d.w, d.h);
    }

    // Trees
    for (const t of this.trees) t.draw(ctx);

    // Active tree indicator
    const at = this.trees[this.activeTreeIndex];
    if (at) {
      const cx = at.x + at.width / 2;
      const pulse = 0.5 + Math.sin(this.time * 3) * 0.25;
      ctx.save();
      ctx.strokeStyle = `rgba(255, 221, 102, ${0.4 + pulse * 0.4})`;
      ctx.lineWidth = 3;
      ctx.setLineDash([6, 6]);
      ctx.beginPath();
      ctx.ellipse(cx, this.groundY + 2, 36, 10, 0, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
      // Arrow above active tree
      const topY = this.groundY - at.visualHeight() - 20;
      ctx.fillStyle = '#ff8a65';
      ctx.beginPath();
      ctx.moveTo(cx, topY + 10 + Math.sin(this.time * 4) * 3);
      ctx.lineTo(cx - 8, topY);
      ctx.lineTo(cx + 8, topY);
      ctx.closePath();
      ctx.fill();
    }

    // Foreground flowers
    for (const d of this.decor) {
      if (d.sprite !== 'flower') continue;
      const img = lib.sprite(d.sprite);
      if (img) ctx.drawImage(img, d.x, d.y, d.w, d.h);
    }

    // Particles on top
    for (const p of this.particles) p.draw(ctx);
  }
}
